const NETWORK = {
  eth: "eth",
  sol: "sol",
};

module.exports = {
  NETWORK,
};
